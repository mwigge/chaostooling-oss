"""Cassandra connection exhaustion status probe."""

import os

import logging

from contextlib import nullcontext

import time

from typing import Optional, Dict

from cassandra.cluster import Cluster

from chaosotel import (

    flush,

    get_metrics_core,

    get_metric_tags,

    get_tracer,

)

from opentelemetry.sdk._logs import LoggingHandler

from opentelemetry._logs import get_logger_provider

from opentelemetry.trace import StatusCode



def probe_connection_exhaustion_status(

    host: Optional[str] = None,

    port: Optional[int] = None,

    keyspace: Optional[str] = None,

    user: Optional[str] = None,

    password: Optional[str] = None,

) -> Dict:

    """

    Probe to check Cassandra connection exhaustion status.

    Observability: Uses chaosotel (chaostooling-otel) as the central observability location. chaosotel must be initialized via chaosotel.control in the experiment configuration.

    """

    host = host or os.getenv("CASSANDRA_HOST", "localhost")

    port = port or int(os.getenv("CASSANDRA_PORT", "9042"))

    keyspace = keyspace or os.getenv("CASSANDRA_KEYSPACE", "system")

    user = user or os.getenv("CASSANDRA_USER")

    password = password or os.getenv("CASSANDRA_PASSWORD")

    

    # chaosotel is initialized via chaosotel.control - use directly

    tracer = get_tracer()

    # Setup OpenTelemetry logger via LoggingHandler

    logger_provider = get_logger_provider()

    if logger_provider:

        handler = LoggingHandler(level=logging.INFO, logger_provider=logger_provider)

        logger = logging.getLogger("chaosdb.cassandra.cassandra_connection_exhaustion_status")

        logger.addHandler(handler)

        logger.setLevel(logging.INFO)

    else:

        logger = logging.getLogger("chaosdb.cassandra.cassandra_connection_exhaustion_status")

    metrics = get_metrics_core()

    

    db_system = "cassandra"

    database = keyspace

    start = time.time()

    span = None

    

    span_context = (

            tracer.start_as_current_span("probe.cassandra.connection_exhaustion_status")

            if tracer

            else nullcontext()

        )

        

    with span_context as span:

        try:





        

            if span:

                span.set_attribute("db.system", db_system)

                span.set_attribute("db.name", database)

                span.set_attribute("db.operation", "probe_connection_exhaustion")

                span.set_attribute("chaos.activity", "cassandra_connection_exhaustion_status")

                span.set_attribute("chaos.activity.type", "probe")

                span.set_attribute("chaos.system", "cassandra")

                span.set_attribute("chaos.operation", "connection_exhaustion_status")

            

            cluster = Cluster([host], port=port)

            session = cluster.connect(keyspace)

            

            # Get native transport connections

            try:

                result = session.execute("SELECT native_transport_active FROM system.local")

                native_connections = result.one()[0] if result else 0

            except:

                native_connections = 0

            

            # Get client requests (indicates active connections)

            try:

                result = session.execute("SELECT client_requests FROM system.local")

                client_requests = result.one()[0] if result else 0

            except:

                client_requests = 0

            

            session.shutdown()

            cluster.shutdown()

            

            probe_time_ms = (time.time() - start) * 1000

            

            tags = get_metric_tags(

                db_name=database,

                db_system=db_system,

                db_operation="probe_connection_exhaustion",

            )

            metrics.record_db_query_latency(

                probe_time_ms,

                db_system=db_system,

                db_name=database,

                db_operation="probe_connection_exhaustion",

                tags=tags,

            )

            metrics.record_db_query_count(

                db_system=db_system,

                db_name=database,

                db_operation="probe_connection_exhaustion",

                count=1,

                tags=tags,

            )

            

            result = {

                "success": True,

                "native_connections": native_connections,

                "client_requests": client_requests,

                "probe_time_ms": probe_time_ms

            }

            

            if span:

                span.set_attribute("chaos.native_connections", native_connections)

                span.set_attribute("chaos.client_requests", client_requests)

                span.set_status(StatusCode.OK)

            

            logger.info(f"Cassandra connection exhaustion probe: {result}")

            flush()

            return result

    except Exception as e:
            db_system=db_system,

            error_type=type(e).__name__,

            db_name=database,

        )

        if span:

            span.record_exception(e)

            span.set_status(StatusCode.ERROR, str(e))

        logger.error(f"Cassandra connection exhaustion probe failed: {str(e)}", extra={"error": str(e)})

        flush()

        return {"success": False, "error": str(e)}
