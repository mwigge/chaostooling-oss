"""MySQL lock storm chaos action."""
import os
import mysql.connector
import time
import threading
import logging
from typing import Optional, Dict
from chaosotel import (
    ensure_initialized,
    get_tracer,
    flush,
    get_metrics_core,
    get_metric_tags,
)
from opentelemetry.trace import StatusCode

_active_threads = []
_stop_event = threading.Event()

def _prepare_table(host: str, port: int, database: str, user: str, password: str, table_name: str, logger):
    """Prepare test table if it doesn't exist."""
    try:
        conn = mysql.connector.connect(
            host=host, port=port, database=database,
            user=user, password=password, connect_timeout=5
        )
        conn.autocommit = True
        cursor = conn.cursor()
        
        cursor.execute(f"""
            CREATE TABLE IF NOT EXISTS {table_name} (
                id INT AUTO_INCREMENT PRIMARY KEY,
                value INT,
                locked_by INT
            )
        """)
        
        # Ensure locked_by column exists
        try:
            cursor.execute(f"ALTER TABLE {table_name} ADD COLUMN locked_by INT")
        except mysql.connector.errors.ProgrammingError:
            # Column already exists
            pass
        
        cursor.execute(f"SELECT COUNT(*) FROM {table_name}")
        if cursor.fetchone()[0] < 2:
            cursor.execute(f"TRUNCATE TABLE {table_name}")
            cursor.execute(f"INSERT INTO {table_name} (value) VALUES (1), (2), (3), (4), (5)")
        
        cursor.close()
        conn.close()
    except Exception as e:
        logger.warning(f"Failed to prepare table {table_name}: {e}")

def inject_lock_storm(
    host: Optional[str] = None,
    port: Optional[int] = None,
    database: Optional[str] = None,
    user: Optional[str] = None,
    password: Optional[str] = None,
    num_threads: int = 10,
    duration_seconds: int = 60,
    table_name: str = "chaos_test_table"
) -> Dict:
    """
    Inject a database lock storm by creating multiple concurrent transactions
    that lock the same rows, causing contention.
    
    Args:
        host: MySQL host
        port: MySQL port
        database: Database name
        user: Database user
        password: Database password
        num_threads: Number of concurrent threads creating locks
        duration_seconds: How long to run the lock storm
        table_name: Table to use for lock contention
        
    Returns:
        Dict with results including locks created, deadlocks detected, etc.
    """
    # Handle string input from Chaos Toolkit configuration
    if port is not None:
        port = int(port) if isinstance(port, str) else port
    num_threads = int(num_threads) if isinstance(num_threads, str) else num_threads
    duration_seconds = int(duration_seconds) if isinstance(duration_seconds, str) else duration_seconds
    
    host = host or os.getenv("MYSQL_HOST", "localhost")
    port = port or int(os.getenv("MYSQL_PORT", "3306"))
    database = database or os.getenv("MYSQL_DB", "testdb")
    user = user or os.getenv("MYSQL_USER", "root")
    password = password or os.getenv("MYSQL_PASSWORD", "")
    db_system = os.getenv("DB_SYSTEM", "mysql")
    
    ensure_initialized()
    tracer = get_tracer()
    logger = logging.getLogger("chaosdb.mysql.lock_storm")
    metrics = get_metrics_core()
    start_time = time.time()

    # Prepare table once to ensure schema contains locked_by column
    _prepare_table(host, port, database, user, password, table_name, logger)
    
    global _active_threads, _stop_event
    _stop_event.clear()
    _active_threads = []
    
    locks_created = 0
    deadlocks_detected = 0
    errors = 0
    
    def lock_worker(thread_id: int):
        """Worker thread that creates and holds locks."""
        nonlocal locks_created, deadlocks_detected, errors
        conn = None
        try:
            with tracer.start_as_current_span(f"lock_storm.worker.{thread_id}") as span:
                span.set_attribute("db.system", db_system)
                span.set_attribute("db.name", database)
                span.set_attribute("chaos.thread_id", thread_id)
                span.set_attribute("chaos.action", "lock_storm")
                span.set_attribute("chaos.activity", "mysql_lock_storm")
                span.set_attribute("chaos.activity.type", "action")
                span.set_attribute("chaos.system", "mysql")
                span.set_attribute("chaos.operation", "lock_storm")
                
                conn = mysql.connector.connect(
                    host=host, port=port, database=database,
                    user=user, password=password, connect_timeout=5
                )
                conn.autocommit = False
                cursor = conn.cursor()
                
                primary_id = 1 if (thread_id % 2) == 0 else 2
                secondary_id = 2 if primary_id == 1 else 1

                # Continuously create locks with alternating order to force contention
                while not _stop_event.is_set():
                    try:
                        txn_start = time.time()
                        cursor.execute("START TRANSACTION")

                        # Lock the first row
                        cursor.execute(
                            f"SELECT id FROM {table_name} WHERE id = %s FOR UPDATE",
                            (primary_id,),
                        )
                        cursor.fetchone()

                        time.sleep(0.2)  # give other threads time to grab the opposite row

                        # Lock the second row (opposite order for half the threads)
                        cursor.execute(
                            f"SELECT id FROM {table_name} WHERE id = %s FOR UPDATE",
                            (secondary_id,),
                        )
                        cursor.fetchone()

                        locks_created += 1

                        # Hold locks briefly to increase overlap
                        time.sleep(0.3)

                        try:
                            cursor.execute(
                                f"UPDATE {table_name} SET locked_by = %s WHERE id = %s",
                                (thread_id, primary_id),
                            )
                            cursor.execute(
                                f"UPDATE {table_name} SET locked_by = %s WHERE id = %s",
                                (thread_id, secondary_id),
                            )
                            conn.commit()
                        except mysql.connector.errors.DatabaseError as e:
                            error_msg = str(e).lower()
                            if "deadlock" in error_msg or "1213" in str(e):
                                deadlocks_detected += 1
                                metrics.record_db_error(
                                    db_system=db_system,
                                    error_type="Deadlock",
                                    db_name=database,
                                )
                                logger.warning(
                                    f"Deadlock detected in thread {thread_id}: {e}"
                                )
                            conn.rollback()

                        txn_duration_ms = (time.time() - txn_start) * 1000
                        tags = get_metric_tags(
                            db_name=database,
                            db_system=db_system,
                            db_operation="lock_storm",
                        )
                        metrics.record_db_query_latency(
                            txn_duration_ms,
                            db_system=db_system,
                            db_name=database,
                            db_operation="lock_storm",
                            tags=tags,
                        )

                        span.set_status(StatusCode.OK)
                    except Exception as e:
                        errors += 1
                        metrics.record_db_error(
                            db_system=db_system,
                            error_type=type(e).__name__,
                            db_name=database,
                        )
                        logger.error(f"Lock storm worker {thread_id} error: {e}")
                        span.set_status(StatusCode.ERROR, str(e))
                        if conn:
                            try:
                                conn.rollback()
                            except:
                                pass
                        time.sleep(0.1)  # Brief pause before retry
                        
        except Exception as e:
            errors += 1
            logger.error(f"Lock storm worker {thread_id} failed: {e}")
        finally:
            if conn:
                try:
                    conn.close()
                except:
                    pass
    
    try:
        with tracer.start_as_current_span("chaos.mysql.lock_storm") as span:
            span.set_attribute("db.system", db_system)
            span.set_attribute("db.name", database)
            span.set_attribute("chaos.num_threads", num_threads)
            span.set_attribute("chaos.duration_seconds", duration_seconds)
            span.set_attribute("chaos.action", "lock_storm")
            span.set_attribute("chaos.activity", "mysql_lock_storm")
            span.set_attribute("chaos.activity.type", "action")
            span.set_attribute("chaos.system", "mysql")
            span.set_attribute("chaos.operation", "lock_storm")
            
            logger.info(f"Starting lock storm with {num_threads} threads for {duration_seconds}s")
            
            # Start worker threads
            for i in range(num_threads):
                thread = threading.Thread(target=lock_worker, args=(i,), daemon=True)
                thread.start()
                _active_threads.append(thread)
            
            # Wait for duration
            time.sleep(duration_seconds)
            
            # Stop all threads
            _stop_event.set()
            for thread in _active_threads:
                thread.join(timeout=5)
            
            duration_ms = (time.time() - start_time) * 1000
            
            result = {
                "success": True,
                "duration_ms": duration_ms,
                "locks_created": locks_created,
                "deadlocks_detected": deadlocks_detected,
                "errors": errors,
                "threads_used": num_threads
            }
            
            span.set_attribute("chaos.locks_created", locks_created)
            span.set_attribute("chaos.deadlocks_detected", deadlocks_detected)
            span.set_attribute("chaos.errors", errors)
            span.set_status(StatusCode.OK)
            
            logger.info(f"Lock storm completed: {result}")
            flush()
            return result
            
    except Exception as e:
        _stop_event.set()
        metrics.record_db_error(
            db_system=db_system,
            error_type=type(e).__name__,
            db_name=database,
        )
        logger.error(f"Lock storm failed: {e}")
        flush()
        raise


def stop_lock_storm():
    """Stop any running lock storm."""
    global _stop_event, _active_threads
    _stop_event.set()
    for thread in _active_threads:
        thread.join(timeout=2)
    _active_threads = []
