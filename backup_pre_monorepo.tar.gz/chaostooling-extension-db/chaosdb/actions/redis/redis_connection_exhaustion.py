"""Redis connection exhaustion chaos action."""
import os
import time
import threading
from typing import Optional, Dict

import redis

from chaosotel import (
    ensure_initialized,
    get_tracer,
    get_logger,
    flush,
    get_metrics_core,
)
from opentelemetry.trace import StatusCode

_active_connections = []
_stop_event = threading.Event()

def inject_connection_exhaustion(
    host: Optional[str] = None,
    port: Optional[int] = None,
    password: Optional[str] = None,
    num_connections: int = 100,
    hold_duration_seconds: int = 60,
    leak_connections: bool = False
) -> Dict:
    """Exhaust Redis connection pool."""
    host = host or os.getenv("REDIS_HOST", "localhost")
    port = port or int(os.getenv("REDIS_PORT", "6379"))
    password = password or os.getenv("REDIS_PASSWORD", None)
    
    ensure_initialized()
    db_system = os.getenv("DB_SYSTEM", "redis")
    metrics = get_metrics_core()
    tracer = get_tracer()
    logger = get_logger()
    start_time = time.time()
    
    global _active_connections, _stop_event
    _stop_event.clear()
    _active_connections = []
    
    connections_created = 0
    connections_failed = 0
    errors = 0
    
    def create_and_hold_connection(conn_id: int):
        nonlocal connections_created, connections_failed, errors
        r = None
        try:
            with tracer.start_as_current_span(
                f"connection_exhaustion.connection.{conn_id}"
            ) as span:
                span.set_attribute("db.system", db_system)
                span.set_attribute("chaos.connection_id", conn_id)
                span.set_attribute("chaos.action", "connection_exhaustion")
                span.set_attribute("chaos.activity", "redis_connection_exhaustion")
                span.set_attribute("chaos.activity.type", "action")
                span.set_attribute("chaos.system", "redis")
                span.set_attribute("chaos.operation", "connection_exhaustion")

                try:
                    r = redis.Redis(
                        host=host, port=port, password=password, decode_responses=True
                    )
                    r.ping()  # Test connection

                    connections_created += 1

                    _active_connections.append(r)

                    end_time = time.time() + hold_duration_seconds
                    while not _stop_event.is_set() and time.time() < end_time:
                        try:
                            r.ping()
                            time.sleep(1)
                        except Exception as e:
                            logger.warning(
                                f"Connection {conn_id} error during hold: {e}"
                            )
                            break

                    span.set_status(StatusCode.OK)
                except redis.ConnectionError as e:
                    connections_failed += 1
                    metrics.record_db_error(
                        db_system=db_system,
                        error_type=type(e).__name__,
                        db_name="redis",
                    )
                    logger.warning(f"Failed to create connection {conn_id}: {e}")
                    span.set_status(StatusCode.ERROR, str(e))
        except Exception as e:
            errors += 1
            logger.error(f"Connection {conn_id} failed: {e}")
        finally:
            if r and not leak_connections:
                try:
                    r.close()
                except Exception:
                    pass
            elif r and leak_connections:
                logger.warning(f"Leaking connection {conn_id} (intentional)")
    
    try:
        with tracer.start_as_current_span("chaos.redis.connection_exhaustion") as span:
            span.set_attribute("db.system", db_system)
            span.set_attribute("chaos.num_connections", num_connections)
            span.set_attribute("chaos.hold_duration_seconds", hold_duration_seconds)
            span.set_attribute("chaos.leak_connections", leak_connections)
            span.set_attribute("chaos.action", "connection_exhaustion")
            span.set_attribute("chaos.activity", "redis_connection_exhaustion")
            span.set_attribute("chaos.activity.type", "action")
            span.set_attribute("chaos.system", "redis")
            span.set_attribute("chaos.operation", "connection_exhaustion")
            
            logger.info(f"Starting Redis connection exhaustion with {num_connections} connections")
            
            threads = []
            for i in range(num_connections):
                thread = threading.Thread(target=create_and_hold_connection, args=(i,), daemon=True)
                thread.start()
                threads.append(thread)
                time.sleep(0.1)
            
            time.sleep(hold_duration_seconds)
            _stop_event.set()
            for thread in threads:
                thread.join(timeout=5)
            
            if not leak_connections:
                for r in _active_connections:
                    try:
                        r.close()
                    except Exception:
                        pass
            
            duration_ms = (time.time() - start_time) * 1000
            
            result = {
                "success": True,
                "duration_ms": duration_ms,
                "connections_created": connections_created,
                "connections_failed": connections_failed,
                "connections_leaked": len(_active_connections) if leak_connections else 0,
                "errors": errors,
                "target_connections": num_connections
            }
            
            span.set_attribute("chaos.connections_created", connections_created)
            span.set_attribute("chaos.connections_failed", connections_failed)
            span.set_status(StatusCode.OK)
            
            logger.info(f"Redis connection exhaustion completed: {result}")
            flush()
            return result
    except Exception as e:
        _stop_event.set()
        metrics.record_db_error(
            db_system=db_system, error_type=type(e).__name__, db_name="redis"
        )
        logger.error(f"Redis connection exhaustion failed: {e}")
        flush()
        raise

def stop_connection_exhaustion():
    global _stop_event, _active_connections
    _stop_event.set()
    for r in _active_connections:
        try:
            r.close()
        except:
            pass
    _active_connections = []

